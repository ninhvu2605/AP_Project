package entity;

public class Qualification {

	private String qaID;
	private String qaName;
	private String qaDescription;

	public String getQaID() {
		return this.qaID;
	}

	/**
	 * 
	 * @param qaID
	 */
	public void setQaID(String qaID) {
		this.qaID = qaID;
	}

	public String getQaName() {
		return this.qaName;
	}

	/**
	 * 
	 * @param qaName
	 */
	public void setQaName(String qaName) {
		this.qaName = qaName;
	}

	public String getQaDescription() {
		return this.qaDescription;
	}

	/**
	 * 
	 * @param qaDescription
	 */
	public void setQaDescription(String qaDescription) {
		this.qaDescription = qaDescription;
	}

}