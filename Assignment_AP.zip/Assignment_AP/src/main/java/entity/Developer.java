package entity;

public class Developer extends Employee {

	private int dvOvertime;

	public int getDvOvertime() {
		return this.dvOvertime;
	}

	/**
	 * 
	 * @param dvOvertime
	 */
	public void setDvOvertime(int dvOvertime) {
		this.dvOvertime = dvOvertime;
	}

}