package entity;

public class Tester extends Employee {

	private int tsBugsFound;

	public int getTsBugsFound() {
		return this.tsBugsFound;
	}

	/**
	 * 
	 * @param tsBugsFound
	 */
	public void setTsBugsFound(int tsBugsFound) {
		this.tsBugsFound = tsBugsFound;
	}

}