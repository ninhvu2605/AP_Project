package model;

import entity.Employee;

public class ActionEmployee implements Action {

	private ArrayList<Employee> listEm;

}