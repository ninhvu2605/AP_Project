package model;

import entity.Salary;

public class ActionSalary implements Action {

	private ArrayList<Salary> listSl;

}