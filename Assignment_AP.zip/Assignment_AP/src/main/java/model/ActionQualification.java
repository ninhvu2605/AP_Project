package model;

import entity.Qualification;

public class ActionQualification implements Action {

	private ArrayList<Qualification> listQa;

}